<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Catalog</title>
    <style>
    body{
      background: #c7b39b url(https://funart.pro/uploads/posts/2020-04/1587312729_54-p-foni-dlya-stranits-saitov-111.jpg);
      color: #fff;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
<link rel="stylesheet" href="/css/style.css">
  </head>
  <body>
    <header>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <div class="container-xxl">
    <a class="navbar-brand" href="#">Bookstore</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">Home</a>
        </li>

        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Dropdown
          </a>
          <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
            <li><a class="dropdown-item" href="#">Action</a></li>
            <li><a class="dropdown-item" href="#">Another action</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="#">Something else here</a></li>
          </ul>
        </li>

      </ul>
      <form class="d-flex">
        <input class="form-control me-2" type="search" placeholder="Search books" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
    </header>

    <section>
      <div class="container-xxl">
        <h2>Books</h2>
        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="row">

        <div class="col">
          <div class="card" style="width: 18rem;">
        <img src="https://img-gorod.ru/26/946/2694633_detail.jpg" class="card-img-top" alt="1">
        <div class="card-body">
          <h5 class="card-title">Развивай свой мозг</h5>
          <p class="card-text">author: Доктор Джо Диспенза</p>
          <a href="#" class="btn btn-primary">more</a>
        </div>
      </div>
        </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://shop.kp.ru/catalog/media/kplitres/9/3/5f4fda856e293.jpg" class="card-img-top" alt="2">
    <div class="card-body">
      <h5 class="card-title">Похититель бабочек</h5>
      <p class="card-text">author: Кристиан Роберт Винд</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
  </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://upload-7df14150aa387ef737992a43afb5ffe5.hb.bizmrg.com/iblock/8f9/8f97f265dabccef7be0d5ffd0b2d3f64/afc10bdb89b670f53a1fb8a384d5d833.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Подсознание может все</h5>
      <p class="card-text">author: Джон Кхео</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
  </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://image-cdn.kazanexpress.ru/budrt2paof0ndh40ljcg/original.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Не тупи</h5>
      <p class="card-text">author: Джен Синсеро</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
  </div>
    </div>
  </div>

    </div>
    <div class="carousel-item">
      <div class="row">
        <div class="col">
          <div class="card" style="width: 18rem;">
        <img src="https://covers.zlibcdn2.com/covers/books/a2/91/cd/a291cdf981b2942171abb59533e2b538.jpg" class="card-img-top" alt="1">
        <div class="card-body">
          <h5 class="card-title">Elon Musk</h5>
          <p class="card-text">author: Anna Crowley Redding</p>
          <a href="#" class="btn btn-primary">more</a>
        </div>
      </div>
        </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://kbimages1-a.akamaihd.net/86f484e2-bc44-4aae-a176-16b66b576859/1200/1200/False/insight-33.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Insight</h5>
      <p class="card-text">author: Tasha Eurich</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://knigobox.ru/image/cache/catalog/eksmo/0/383326785-9785001468103-650x650.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Еда и Мозг</h5>
      <p class="card-text">author: Дэвид Перлмуттер</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://narcosis-css.ru/800/600/https/rudenokk.files.wordpress.com/2020/06/cover2-draft.png" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Пиши, сокращай</h5>
      <p class="card-text">author: Максим Ильяхов & Людмила Сарычева</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    </div>
    </div>
    <div class="carousel-item">
      <div class="row">
        <div class="col">
          <div class="card" style="width: 18rem;">
        <img src="https://fitabooks.ru/wp-content/uploads/2020/11/9398910-986x1536.jpg" class="card-img-top" alt="1">
        <div class="card-body">
          <h5 class="card-title">Дотянуться до звезд</h5>
          <p class="card-text">author: Эмма Скот</p>
          <a href="#" class="btn btn-primary">more</a>
        </div>
      </div>
        </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://cdn.eksmo.ru/v2/ITD000000000981210/COVER/cover1.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Save me</h5>
      <p class="card-text">author: Mona Kasten</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://antique.newbookshop.ru/pict/1025405520.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Магия утра</h5>
      <p class="card-text">author: Хэл Элрод</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    <div class="col">
      <div class="card" style="width: 18rem;">
    <img src="https://diwanegypt.com/wp-content/uploads/2020/08/9781510105249.jpg" class="card-img-top" alt="1">
    <div class="card-body">
      <h5 class="card-title">Shadow and Bone</h5>
      <p class="card-text">author: Leigh Bardugo</p>
      <a href="#" class="btn btn-primary">more</a>
    </div>
    </div>
    </div>
    </div>
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
        </div>
    </section>
    <section>

    </section>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
  </body>
</html>
